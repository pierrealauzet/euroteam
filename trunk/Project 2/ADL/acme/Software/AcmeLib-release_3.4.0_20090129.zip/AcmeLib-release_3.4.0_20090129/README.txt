AcmeLib 3 Runtime
=================

This distribution contains the AcmeLib runtime and parser, 
which can be used for standalone parsing and checking of Acme 
descriptions, as well as for the development of architectural
manipulation code that is not dependent of AcmeStudio.

Installation
------------

To install this file, unzip the distribution. The distribution 
consists of the following files:

  README          -- this file
  lib/AcmeLib.jar -- the jar file containing the parser and model 
                     code
  families/*      -- directory containing built-in Acme families
  demo/           -- directory containing some sample code and Acme
                     files

To enable the parser and libraries to find the families directory,
ensure that the families directory is on the classpath.

Running
-------

To parse and check an Acme description:

> java org.acmestudio.standalone.Parser file.acme

Errors will be printed to the console.

                     